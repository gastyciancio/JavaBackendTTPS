package entrega4.DAOInterface;

import entrega4.ModelClasses.FormaPago;

public interface FormaPagoDAO extends GenericDAO<FormaPago> {

}
